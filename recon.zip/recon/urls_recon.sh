#!/bin/bash

# File paths
SUBDOMAINS_FILE="subdomains.txt"
http_file = "http.txt"
OUTPUT_DIR="output_urls"
EXCLUDE_EXTENSIONS="\.(css|jpg|png|jpeg|gif|svg|woff|woff2|ttf|ico)$"

# Check if subdomains file exists
if [[ ! -f "$SUBDOMAINS_FILE" ]]; then
    echo "[-] File 'subdomains.txt' not found. Please provide a list of subdomains."
    exit 1
fi

if [[ ! -f "$http_file" ]]; then
    echo "[-] File 'http_file' not found. Please provide it ."
    exit 1
fi

# Create output directory
mkdir -p "$OUTPUT_DIR"
echo "[+] Starting URL collection for subdomains in $SUBDOMAINS_FILE"
echo "[+] Output directory: $OUTPUT_DIR"

# 2. GoSpider
echo "[+] Running GoSpider for $subdomain..."
    
gospider -S "$SUBDOMAINS_FILE" -d 2 --include-subs --js --other-source --quiet -o "OUTPUT_DIR" || echo "[-] GoSpider failed for $subdomain"
	
# 3. LinkFinder
echo "[+] Running LinkFinder for $subdomain..."

cat http_file | parallel -j10 "python3 /mnt/f/bugbounty/LinkFinder/linkfinder.py -i {} -o cli >> OUTPUT_DIR/linkfinder_output.txt"

# 4. Hakrawler
echo "[+] Running Hakrawler for $subdomain..."

cat http_file | hakrawler -d 2 -subs |  tee  OUTPUT_DIR/hakrawler_all.txt || echo "[-] Hakrawler failed for $subdomain"


# 5. Katana
echo "[+] Running Katana for $subdomain..."

katana -list SUBDOMAINS_FILE -d 3 | tee  OUTPUT_DIR/katana_all.txt || echo "[-] Katana failed for $subdomain"

#. 6 Paramspider
paramspidr -l SUBDOMAINS_FILE 



# Merge and filter URLs
echo "[+] Merging and filtering URLs for $subdomain..."
cat OUTPUT_DIR/* | tee OUTPUT_DIR/allurls.txt 
cat results/* | tee -a allurls.txt 

## FILTEEEEER

grep -Ev "\.(css|jpg|png|jpeg|gif|svg|woff|woff2|ttf|ico)$" allurls.txt | tee  filtered_urls.txt


echo "[+] URL collection completed for all subdomains."
